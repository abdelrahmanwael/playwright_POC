export default {
    //Test-Environment
    publicUrl: 'https://faseh-web.aks.thiqah.sa/',
    adminUrl: 'https://faseh-admin.aks.thiqah.sa/',
    //Pre-Environment
    // publicUrl: 'https://fasehpp.thiqah.sa/',
    // adminUrl: 'https://fasehpp-backoffice.thiqah.sa/',
};